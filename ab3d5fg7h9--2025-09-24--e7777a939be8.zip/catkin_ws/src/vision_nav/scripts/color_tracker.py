#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge, CvBridgeError

class ColorTracker:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('color_tracker', anonymous=True)

        # Create a CvBridge object to convert ROS images to OpenCV images
        self.bridge = CvBridge()

        # Subscribe to the camera image topic. The topic name is /camera/rgb/image_raw
        self.image_sub = rospy.Subscriber('/camera/rgb/image_raw', Image, self.image_callback)

        # Publish movement commands to the /cmd_vel topic
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

        # Create a Twist message object to hold velocity commands
        self.twist = Twist()

    def image_callback(self, msg):
        try:
            # Convert the ROS Image message to an OpenCV image (BGR format)
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        # Get image dimensions
        h, w, d = cv_image.shape

        # Convert the BGR image to HSV (Hue, Saturation, Value) color space
        # HSV is better for color detection than BGR
        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

        # --- COLOR DEFINITION ---
        # Define the lower and upper bounds for the BLUE color in HSV
        # You may need to adjust these values for your specific object/lighting
        lower_blue = np.array([100, 150, 50])
        upper_blue = np.array([140, 255, 255])
        
        # Create a mask that isolates the blue pixels
        mask = cv2.inRange(hsv_image, lower_blue, upper_blue)

        # Find contours (outlines of the shapes) in the mask
        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # --- OBJECT DETECTION LOGIC ---
        if len(contours) > 0:
            # Find the largest contour, assuming it's our target object
            c = max(contours, key=cv2.contourArea)

            # Calculate the moments of the contour to find its center (centroid)
            M = cv2.moments(c)

            # Avoid division by zero
            if M['m00'] > 0:
                # cx, cy are the coordinates of the object's center in the image
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])

                # Draw a circle at the center of the object for visualization
                cv2.circle(cv_image, (cx, cy), 5, (0, 255, 0), -1)

                # --- NAVIGATION LOGIC ---
                # Divide the screen into three regions: left, center, right
                err = cx - w / 2

                # If the object's center is in the middle 20% of the screen, move forward
                if abs(err) < w * 0.1: # Threshold of 10% on each side
                    rospy.loginfo("Object centered, moving forward")
                    self.twist.linear.x = 0.2  # Set forward speed
                    self.twist.angular.z = 0.0 # Stop turning
                # If the object is to the left, turn left
                elif err < 0:
                    rospy.loginfo("Object on the left, turning left")
                    self.twist.linear.x = 0.0  # Stop moving forward
                    self.twist.angular.z = 0.4  # Set turning speed
                # If the object is to the right, turn right
                else:
                    rospy.loginfo("Object on the right, turning right")
                    self.twist.linear.x = 0.0  # Stop moving forward
                    self.twist.angular.z = -0.4 # Set turning speed (negative for right)
            else:
                # If moments can't be calculated, stop
                self.stop_robot()
        else:
            # If no contours are found (object not in view), stop the robot
            rospy.loginfo("No object detected, stopping")
            self.stop_robot()

        # Publish the velocity command
        self.cmd_vel_pub.publish(self.twist)

        # Optional: Display the image with the tracking circle for debugging
        # Note: This won't display in TheConstruct's default setup, but is good practice
        # cv2.imshow("Tracking", cv_image)
        # cv2.waitKey(1)

    def stop_robot(self):
        """A helper function to stop the robot."""
        self.twist.linear.x = 0.0
        self.twist.angular.z = 0.0

if __name__ == '__main__':
    try:
        # Create an instance of our class
        tracker = ColorTracker()
        # Keep the node running until it's shut down
        rospy.spin()
    except rospy.ROSInterruptException:
        pass